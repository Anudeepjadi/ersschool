﻿import 'dart:io';
import 'package:flutter/material.dart';
import '../../../../core/theme/app_colors.dart';
import '../../../../core/utils/profile_manager.dart';
import '../../my_info/my_info_screen.dart';
import '../../../../widgets/calendar_popup.dart';
import '../widgets/student_app_bar.dart';
import '../../transport/transport_screen.dart';

class HomeTab extends StatelessWidget {
  final VoidCallback onOpenDrawer;
  final Function(int) onTabSelected;

  const HomeTab({
    super.key,
    required this.onOpenDrawer,
    required this.onTabSelected,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: StudentAppBar(
        title: "Welcome Student 👋",
        subtitle: "Here's what's happening today.",
        onOpenDrawer: onOpenDrawer,
        onProfileTap: () => onTabSelected(1),
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          // Simulate a network request
          await Future.delayed(const Duration(seconds: 1));
        },
        child: SingleChildScrollView(
          physics: const AlwaysScrollableScrollPhysics(parent: BouncingScrollPhysics()),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 16, right: 16, top: 4, bottom: 16),
                child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // 2. Welcome Back Card
                Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: const Color(0xFFEBF3FF),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  padding: const EdgeInsets.all(20),
                  child: Row(
                    children: [
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Welcome Back!",
                              style: TextStyle(
                                fontSize: 22,
                                fontWeight: FontWeight.bold,
                                color: Color(0xFF1E2875),
                              ),
                            ),
                            SizedBox(height: 8),
                            Text(
                              "Stay focused and\nkeep learning every day.",
                              style: TextStyle(
                                fontSize: 13,
                                color: Color(0xFF5A629B),
                                height: 1.4,
                                fontWeight: FontWeight.w500,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Image.asset(
                        "assets/images/student_welcome.png",
                        height: 120,
                        errorBuilder: (context, error, stackTrace) {
                          return const Icon(
                            Icons.school,
                            size: 80,
                            color: AppColors.primary,
                          );
                        },
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 25),

                // 3. Quick Access Section
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      "Quick Access",
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: AppColors.text,
                      ),
                    ),
                    TextButton(
                      onPressed: () {
                        onTabSelected(5); // Switch to More tab
                      },
                      child: const Text(
                        "View All",
                        style: TextStyle(
                          color: AppColors.primary,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),

                // Row of quick access items
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  physics: const BouncingScrollPhysics(),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildQuickAccessItem(
                        Icons.school_outlined,
                        "My Class",
                        Colors.blue,
                        onTap: () => onTabSelected(2),
                      ),
                      _buildQuickAccessItem(
                        Icons.library_books_outlined,
                        "Learning\nMaterials",
                        Colors.green,
                        onTap: () => onTabSelected(5),
                      ),
                      _buildQuickAccessItem(
                        Icons.assignment_outlined,
                        "Exams",
                        Colors.purple,
                        onTap: () => onTabSelected(4),
                      ),
                      _buildQuickAccessItem(
                        Icons.currency_rupee,
                        "Fee\nPayment",
                        Colors.orange,
                        onTap: () => onTabSelected(3),
                      ),
                      _buildQuickAccessItem(
                        Icons.calendar_today_outlined,
                        "Calendar",
                        Colors.pink,
                        onTap: () {
                          showCalendarPopup(context);
                        },
                      ),
                      _buildQuickAccessItem(
                        Icons.directions_bus_outlined,
                        "Transport",
                        Colors.indigo,
                        onTap: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(builder: (context) => const TransportScreen()),
                          );
                        },
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 25),

                // 4. Today's Schedule Section
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      "Today's Schedule",
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: AppColors.text,
                      ),
                    ),
                    TextButton(
                      onPressed: () {
                        onTabSelected(5); // Switch to More tab for now
                      },
                      child: const Text(
                        "View All",
                        style: TextStyle(
                          color: AppColors.primary,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),

                // Vertical List of Schedule Cards
                _buildScheduleCard(
                  title: "Physics - Class 8",
                  subtitle: "Room 101",
                  time: "10:00 AM - 10:45 AM",
                  icon: Icons.menu_book_outlined,
                  iconColor: Colors.green,
                ),
                _buildScheduleCard(
                  title: "Mathematics - Class 8",
                  subtitle: "Room 102",
                  time: "11:00 AM - 11:45 AM",
                  icon: Icons.calculate_outlined,
                  iconColor: Colors.purple,
                ),
                _buildScheduleCard(
                  title: "Chemistry - Class 8",
                  subtitle: "Room 103",
                  time: "12:00 PM - 12:45 PM",
                  icon: Icons.science_outlined,
                  iconColor: Colors.orange,
                ),
                _buildScheduleCard(
                  title: "English - Class 8",
                  subtitle: "Room 104",
                  time: "01:30 PM - 02:15 PM",
                  icon: Icons.edit_note_outlined,
                  iconColor: Colors.blue,
                ),
                _buildScheduleCard(
                  title: "Computer Science - Class 8",
                  subtitle: "Room 105",
                  time: "02:30 PM - 03:15 PM",
                  icon: Icons.computer_outlined,
                  iconColor: Colors.red,
                ),

                const SizedBox(height: 25),

                // 5. Important Notice Section
                Container(
                  width: double.infinity,
                  decoration: BoxDecoration(
                    color: const Color(0xFFF4F7FF),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(
                      color: const Color(0xFFE0E7FF),
                      width: 1,
                    ),
                  ),
                  padding: const EdgeInsets.all(12),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: AppColors.primary.withValues(alpha: 0.1),
                          shape: BoxShape.circle,
                        ),
                        child: const Icon(
                          Icons.campaign_outlined,
                          color: AppColors.primary,
                          size: 20,
                        ),
                      ),
                      const SizedBox(width: 12),
                      const Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              "Important Notice",
                              style: TextStyle(
                                fontSize: 12,
                                fontWeight: FontWeight.bold,
                                color: Color(0xFF1E2875),
                              ),
                            ),
                            SizedBox(height: 4),
                            Text(
                              "Science Exhibition is scheduled on 24 Jun 2026 at School Auditorium.",
                              style: TextStyle(
                                fontSize: 10,
                                color: Colors.black87,
                                height: 1.3,
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 8),
                      TextButton(
                        onPressed: () {
                          onTabSelected(5); // Switch to More tab
                        },
                        style: TextButton.styleFrom(
                          minimumSize: Size.zero,
                          padding: EdgeInsets.zero,
                          tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                        ),
                        child: const Text(
                          "View All",
                          style: TextStyle(
                            fontSize: 12,
                            color: AppColors.primary,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 25),

                // 6. Upcoming Events Section
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text(
                      "Upcoming Events",
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: AppColors.text,
                      ),
                    ),
                    TextButton(
                      onPressed: () => showCalendarPopup(context),
                      child: const Text(
                        "View Calendar",
                        style: TextStyle(
                          color: AppColors.primary,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10),

                // Event cards
                _buildEventCard(
                  title: "Parents Teacher Meeting",
                  datetime: "25 Jun 2026 | 09:00 AM - 11:00 AM",
                  location: "Conference Hall",
                  color: Colors.green,
                ),
                _buildEventCard(
                  title: "Science Exhibition",
                  datetime: "24 Jun 2026 | 10:00 AM - 02:00 PM",
                  location: "School Auditorium",
                  color: Colors.purple,
                ),
              ],
            ),
          ),
        ],
      ),
      ),
      ),
    );
  }

  Widget _buildQuickAccessItem(
    IconData icon,
    String label,
    Color color, {
    VoidCallback? onTap,
  }) {
    return Container(
      width: 65,
      margin: const EdgeInsets.only(right: 0),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(12),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 4.0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(icon, color: color, size: 28),
                const SizedBox(height: 8),
                Text(
                  label,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w600,
                    color: Color(0xFF1E2875),
                    height: 1.2,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildScheduleCard({
    required String title,
    required String subtitle,
    required String time,
    required IconData icon,
    required Color iconColor,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.shade100, width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.shade50,
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: iconColor.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: iconColor, size: 16),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF1E2875),
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: TextStyle(fontSize: 10, color: Colors.grey.shade600),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
          Text(
            time,
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.bold,
              color: Colors.grey.shade600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEventCard({
    required String title,
    required String datetime,
    required String location,
    required Color color,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.shade100, width: 1),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.shade50,
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(Icons.event, color: color, size: 16),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF1E2875),
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 4),
                Text(
                  datetime,
                  style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                    color: Colors.grey.shade700,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 2),
                Text(
                  location,
                  style: TextStyle(fontSize: 10, color: Colors.grey.shade500),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

