# Generated code do not commit.
file(TO_CMAKE_PATH "C:\\Users\\DELL\\develop\\flutter" FLUTTER_ROOT)
file(TO_CMAKE_PATH "C:\\Users\\DELL\\ersschool" PROJECT_DIR)

set(FLUTTER_VERSION "1.0.0+1" PARENT_SCOPE)
set(FLUTTER_VERSION_MAJOR 1 PARENT_SCOPE)
set(FLUTTER_VERSION_MINOR 0 PARENT_SCOPE)
set(FLUTTER_VERSION_PATCH 0 PARENT_SCOPE)
set(FLUTTER_VERSION_BUILD 1 PARENT_SCOPE)

# Environment variables to pass to tool_backend.sh
list(APPEND FLUTTER_TOOL_ENVIRONMENT
  "FLUTTER_ROOT=C:\\Users\\DELL\\develop\\flutter"
  "PROJECT_DIR=C:\\Users\\DELL\\ersschool"
  "FLUTTER_ROOT=C:\\Users\\DELL\\develop\\flutter"
  "FLUTTER_EPHEMERAL_DIR=C:\\Users\\DELL\\ersschool\\windows\\flutter\\ephemeral"
  "PROJECT_DIR=C:\\Users\\DELL\\ersschool"
  "FLUTTER_TARGET=C:\\Users\\DELL\\ersschool\\lib\\main.dart"
  "DART_DEFINES=RkxVVFRFUl9WRVJTSU9OPTMuNDEuNA==,RkxVVFRFUl9DSEFOTkVMPVt1c2VyLWJyYW5jaF0=,RkxVVFRFUl9HSVRfVVJMPXVua25vd24gc291cmNl,RkxVVFRFUl9GUkFNRVdPUktfUkVWSVNJT049ZmYzN2JlZjYwMw==,RkxVVFRFUl9FTkdJTkVfUkVWSVNJT049ZTRiOGRjYTNmMQ==,RkxVVFRFUl9EQVJUX1ZFUlNJT049My4xMS4x"
  "DART_OBFUSCATION=false"
  "TRACK_WIDGET_CREATION=true"
  "TREE_SHAKE_ICONS=false"
  "PACKAGE_CONFIG=C:\\Users\\DELL\\ersschool\\.dart_tool\\package_config.json"
)
